


import requests
import json
import pandas as pd
import os
import webbrowser  # Import webbrowser module
from jinja2 import Environment, FileSystemLoader

# anywhere there is a comment is where the api is called

print('Ight bro... I know you need to make some gainz so let\'s make a meal plan!')
print('Before we can set you up a meal plan, check out these bussin meals and see what you like!\n')

def generate_html(meal_plan):
    # Load the Jinja2 template
    env = Environment(loader=FileSystemLoader('.'))
    template = env.get_template('meal_template.html')  # Ensure this file exists

    # Render the HTML
    html_output = template.render(meals=meal_plan)
    
    # Write the rendered HTML to a file
    with open('meal_plan.html', 'w') as f:
        f.write(html_output)

    # Open the generated HTML file in the default web browser
    webbrowser.open('meal_plan.html')

def get_meal_plan():
    start_url = "https://www.themealdb.com/api/json/v1/1/categories.php"
    # API is being Called
    response = requests.get(start_url)
    
    if response.status_code == 200:
        data = response.json()
        categories = [category['strCategory'] for category in data['categories']]
        print("Here are the available categories:")
        for category in categories:
            print(f"- {category}")
    else:
        print(f"Request failed with status code: {response.status_code}")
        return

    meal_plan = []  # Initialize a meal plan list

    while True:
        category_choice = input('\nWhat category would you like to check out? (or type "exit" to finish)\n').capitalize()
        
        if category_choice.lower() == 'exit':
            print("You finished building your meal plan. Enjoy your gainz!")
            if meal_plan:  # If there are meals in the plan, generate HTML
                generate_html(meal_plan)
            break

        if category_choice not in categories:
            print(f"'{category_choice}' is not a valid category. Please choose from the list.")
            continue
        
        category_url = f"https://www.themealdb.com/api/json/v1/1/filter.php?c={category_choice}"
        # API is being Called
        response2 = requests.get(category_url)

        if response2.status_code == 200:
            data = response2.json()
            if data['meals']:
                print("\nHere are the meals from the selected category:")
                meals_list = [meal['strMeal'] for meal in data['meals']]
                for meal in meals_list:
                    print(f"- {meal}")
            else:
                print("No meals found in this category.")
                continue  
        else:
            print(f"Request failed with status code: {response2.status_code}")
            continue

        while True:
            meal_choice = input('\nWhat sounds and looks fire? We\'ll add it to the Meal Plan (or type "back" to choose another category)\n')

            if meal_choice.lower() == 'back':
                break  

            if meal_choice not in meals_list:
                print(f"'{meal_choice}' is not a valid meal. Please choose from the list.")
                continue

            meal_choice_url = f"https://www.themealdb.com/api/json/v1/1/search.php?s={meal_choice}"

            # API is being Called
            response3 = requests.get(meal_choice_url)

            if response3.status_code == 200:
                data = response3.json()

                if data['meals'] is not None:
                    meals = pd.DataFrame(data['meals'])

                    # Prepare meal data
                    meals_df = meals[['strMeal', 'strCategory', 'strArea', 'strInstructions', 'strTags', 'strYoutube']]
                    meal_info = meals_df.iloc[0].to_dict()  # Get the first meal's details

                    # Append meal info to meal plan
                    meal_plan.append(meal_info)

                    print(f"{meal_choice} has been added to your Meal Plan!")
                else:
                    print("No meals found with the given name.")
            else:
                print(f"Request failed with status code: {response3.status_code}")

get_meal_plan()
